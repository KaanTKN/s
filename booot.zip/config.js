const config = {
    "ownerID": "446048541488578569", //kendi IDınızı yazınız
    "admins": ["446048541488578569"],
    "support": ["446048541488578569"],
    "token": "NDg1MTEwODUyNzM5OTIzOTY5.XWXoOA.R7fx41HJF9y-JMHWJvxNndZOPzk", //botunuzun tokenini yazınız
    "dashboard" : {
      "oauthSecret": "lNYupwJAzgSjqLSgnf8z5zZITsalw2K4", //botunuzun secretini yazınız
      "callbackURL": `https://anloxbot-gecilcek.glitch.me/callback`, //site URLnizi yazınız /callback kısmını silmeyiniz!
      "sessionSecret": "xyzxyz", //kalsın
      "domain": "https://anloxbot-gecilcek.glitch.me/" //site URLnizi yazınız!
    }
  };
  
  module.exports = config;